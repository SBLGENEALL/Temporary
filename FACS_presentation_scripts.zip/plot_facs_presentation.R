# =============================================================================
# CHO 5'UTR FACS - Presentation-grade figures
# -----------------------------------------------------------------------------
# Input : Plate_Map.csv + FACS_Data.csv   (same format as the existing bundle)
# Output: FACS_presentation/  (PNG 300 dpi + PDF vector, 16:9 slide friendly)
# Run   : Rscript plot_facs_presentation.R
#
# Design: 31 variants + Original = 32 constructs, 3 replicates each (96 wells),
#         3 readouts = GFP GeoMean (MFI), GFP-positive (%), Live cell (%)
#
# Required packages: dplyr, tidyr, ggplot2, stringr   (ggrepel optional)
# =============================================================================


# ------------------------------ USER SETTINGS --------------------------------

OUTPUT_DIR      <- "FACS_presentation"
ORIGINAL_NAME   <- "Original"     # exact Construct name of the control

# Which timepoint / condition to use for the MAIN figures.
# Leave as NULL to auto-select the Day x Condition with the most complete data.
FOCUS_DAY       <- NULL           # e.g. "D11"
FOCUS_CONDITION <- NULL           # e.g. "GS"

# Also produce the same figure set for every other Day x Condition combination
MAKE_ALL_COMBOS <- TRUE

ERRORBAR        <- "SD"           # "SD" or "SEM"
LOG_MFI_AXIS    <- FALSE          # TRUE if MFI spans more than ~1 order of magnitude
SHOW_STATS      <- TRUE           # Welch t-test vs Original, BH-adjusted
LABEL_TOP_N     <- 8              # how many top constructs to label on the scatter

# Slide geometry (inches). 13.33 x 7.5 = 16:9 full slide.
FIG_W <- 13.33
FIG_H <- 7.5

# Colours
COL_ORIGINAL <- "#D1495B"   # control - red
COL_UP       <- "#1B6CA8"   # above control - blue
COL_DOWN     <- "#B0B7BE"   # below control - grey
COL_MID      <- "#EDF2F4"

# -----------------------------------------------------------------------------


PLATE_MAP_FILE <- "Plate_Map.csv"
FACS_DATA_FILE <- "FACS_Data.csv"

required_packages <- c("dplyr", "tidyr", "ggplot2", "stringr")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0) {
  stop("Missing R packages: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(grid)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(stringr)
})
HAS_REPEL <- requireNamespace("ggrepel", quietly = TRUE)
if (HAS_REPEL) suppressPackageStartupMessages(library(ggrepel))

dir.create(OUTPUT_DIR, showWarnings = FALSE, recursive = TRUE)


# ------------------------------ helpers --------------------------------------

read_csv_utf8 <- function(path) {
  if (!file.exists(path)) stop("File not found: ", path)
  x <- read.csv(path, header = TRUE, check.names = FALSE,
                na.strings = c("", "NA"), quote = "\"", comment.char = "",
                fileEncoding = "UTF-8", stringsAsFactors = FALSE)
  names(x) <- sub(paste0("^", intToUtf8(65279)), "", names(x))
  x
}

clean_numeric <- function(x) {
  x <- as.character(x)
  x <- str_replace_all(x, ",", "")
  x <- str_replace_all(x, "%", "")
  suppressWarnings(as.numeric(x))
}

normalize_well <- function(x) {
  x <- toupper(str_trim(as.character(x)))
  str_remove(x, regex("\\.fcs$", ignore_case = TRUE))
}

# Save both a raster (for pasting into slides) and a vector (for resizing)
save_fig <- function(plot, file, w = FIG_W, h = FIG_H) {
  suppressWarnings(
    ggsave(file.path(OUTPUT_DIR, paste0(file, ".png")), plot,
           width = w, height = h, dpi = 300, bg = "white")
  )
  ok <- try(suppressWarnings(
    ggsave(file.path(OUTPUT_DIR, paste0(file, ".pdf")), plot,
           width = w, height = h, device = "pdf")), silent = TRUE)
  if (inherits(ok, "try-error")) message("  (PDF export skipped for ", file, ")")
  invisible(NULL)
}

# Clean, high-contrast theme sized for a projector
theme_pres <- function(base_size = 15) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title       = element_text(face = "bold", size = base_size + 4,
                                      margin = margin(b = 4)),
      plot.subtitle    = element_text(size = base_size - 1, colour = "#4A5057",
                                      margin = margin(b = 10)),
      plot.caption     = element_text(size = base_size - 4, colour = "#7A828A",
                                      hjust = 0),
      axis.title       = element_text(face = "bold", size = base_size),
      axis.text        = element_text(colour = "#2B2F33"),
      axis.line.x      = element_line(colour = "#2B2F33", linewidth = 0.4),
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.major.y = element_line(colour = "#E4E8EB", linewidth = 0.4),
      strip.text       = element_text(face = "bold", size = base_size),
      legend.position  = "top",
      legend.title     = element_text(face = "bold"),
      plot.margin      = margin(14, 18, 10, 14)
    )
}

sig_star <- function(p) {
  ifelse(is.na(p), "",
    ifelse(p < 0.001, "***",
      ifelse(p < 0.01, "**",
        ifelse(p < 0.05, "*", ""))))
}


# ------------------------------ load & merge ---------------------------------

plate_map_input <- read_csv_utf8(PLATE_MAP_FILE)
facs_input      <- read_csv_utf8(FACS_DATA_FILE)

plate_map <- plate_map_input %>%
  transmute(
    Well      = normalize_well(Well),
    Construct = str_trim(as.character(Construct)),
    Replicate = suppressWarnings(as.integer(Replicate))
  ) %>%
  filter(!is.na(Well), Well != "", !is.na(Construct), Construct != "")

if (nrow(plate_map) == 0) {
  stop("Plate_Map.csv has no Construct entries. Fill in Construct and Replicate first.")
}

dat <- facs_input %>%
  transmute(
    Day              = toupper(str_trim(as.character(Day))),
    Condition        = str_trim(as.character(Condition)),
    Well             = normalize_well(ifelse(is.na(Well) | str_trim(as.character(Well)) == "",
                                             as.character(Sample_File), as.character(Well))),
    Live_Cell_Pct    = clean_numeric(Live_Cell_Pct),
    GFP_Positive_Pct = clean_numeric(GFP_Positive_Pct),
    GFP_GeoMean      = clean_numeric(GFP_GeoMean)
  ) %>%
  mutate(Condition = ifelse(is.na(Condition) | Condition == "", "All", Condition)) %>%
  filter(if_any(c(Live_Cell_Pct, GFP_Positive_Pct, GFP_GeoMean), ~ !is.na(.x))) %>%
  inner_join(plate_map, by = "Well")

if (nrow(dat) == 0) {
  stop("No numeric FACS values matched the plate map. Check Well IDs in both files.")
}

for (col in c("Live_Cell_Pct", "GFP_Positive_Pct")) {
  v <- dat[[col]][!is.na(dat[[col]])]
  if (length(v) > 0 && max(v) <= 1) {
    warning(col, ": all values <= 1. Enter 50% as 50, not 0.50.")
  }
}

if (!any(str_to_lower(dat$Construct) == str_to_lower(ORIGINAL_NAME))) {
  stop("Control '", ORIGINAL_NAME, "' not found in Plate_Map Construct column.")
}
# normalise the control spelling so joins are safe
dat$Construct[str_to_lower(dat$Construct) == str_to_lower(ORIGINAL_NAME)] <- ORIGINAL_NAME

message("Loaded ", nrow(dat), " wells | ",
        length(unique(dat$Construct)), " constructs | ",
        "Days: ", paste(sort(unique(dat$Day)), collapse = ", "), " | ",
        "Conditions: ", paste(sort(unique(dat$Condition)), collapse = ", "))


# ------------------------------ summarise ------------------------------------

summ_all <- dat %>%
  group_by(Day, Condition, Construct) %>%
  summarise(
    n_MFI      = sum(!is.na(GFP_GeoMean)),
    MFI_mean   = mean(GFP_GeoMean, na.rm = TRUE),
    MFI_sd     = sd(GFP_GeoMean, na.rm = TRUE),
    n_pos      = sum(!is.na(GFP_Positive_Pct)),
    Pos_mean   = mean(GFP_Positive_Pct, na.rm = TRUE),
    Pos_sd     = sd(GFP_Positive_Pct, na.rm = TRUE),
    n_live     = sum(!is.na(Live_Cell_Pct)),
    Live_mean  = mean(Live_Cell_Pct, na.rm = TRUE),
    Live_sd    = sd(Live_Cell_Pct, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    MFI_sem  = MFI_sd  / sqrt(pmax(n_MFI, 1)),
    Pos_sem  = Pos_sd  / sqrt(pmax(n_pos, 1)),
    Live_sem = Live_sd / sqrt(pmax(n_live, 1)),
    across(ends_with("_mean"), ~ ifelse(is.nan(.x), NA_real_, .x))
  )

ctrl <- summ_all %>%
  filter(Construct == ORIGINAL_NAME) %>%
  select(Day, Condition,
         Ctrl_MFI = MFI_mean, Ctrl_Pos = Pos_mean, Ctrl_Live = Live_mean)

summ_all <- summ_all %>%
  left_join(ctrl, by = c("Day", "Condition")) %>%
  mutate(
    MFI_fold   = MFI_mean / Ctrl_MFI,
    MFI_pct    = 100 * (MFI_fold - 1),
    Pos_delta  = Pos_mean  - Ctrl_Pos,
    Live_delta = Live_mean - Ctrl_Live
  )

# Welch t-test vs Original, per Day x Condition, BH-adjusted
stat_tbl <- NULL
if (SHOW_STATS) {
  stat_tbl <- dat %>%
    group_by(Day, Condition) %>%
    group_modify(function(d, key) {
      ref <- d$GFP_GeoMean[d$Construct == ORIGINAL_NAME]
      ref <- ref[!is.na(ref)]
      out <- lapply(setdiff(unique(d$Construct), ORIGINAL_NAME), function(cs) {
        v <- d$GFP_GeoMean[d$Construct == cs]
        v <- v[!is.na(v)]
        p <- NA_real_
        if (length(v) >= 2 && length(ref) >= 2 && (sd(v) > 0 || sd(ref) > 0)) {
          tt <- try(t.test(v, ref), silent = TRUE)
          if (!inherits(tt, "try-error")) p <- tt$p.value
        }
        data.frame(Construct = cs, p_raw = p, stringsAsFactors = FALSE)
      })
      bind_rows(out)
    }) %>%
    ungroup() %>%
    group_by(Day, Condition) %>%
    mutate(p_adj = p.adjust(p_raw, method = "BH"),
           star  = sig_star(p_adj)) %>%
    ungroup()

  summ_all <- summ_all %>% left_join(stat_tbl, by = c("Day", "Condition", "Construct"))
} else {
  summ_all$p_raw <- NA_real_; summ_all$p_adj <- NA_real_; summ_all$star <- ""
}

write.csv(dat,      file.path(OUTPUT_DIR, "data_wells_long.csv"),      row.names = FALSE)
write.csv(summ_all, file.path(OUTPUT_DIR, "summary_by_construct.csv"), row.names = FALSE)


# ------------------------------ figure builder -------------------------------

build_figures <- function(summ, raw, tag, title_suffix) {

  err_lo <- function(m, sd, sem) m - if (ERRORBAR == "SEM") sem else sd
  err_hi <- function(m, sd, sem) m + if (ERRORBAR == "SEM") sem else sd
  err_lab <- if (ERRORBAR == "SEM") "mean +/- SEM" else "mean +/- SD"

  # consistent construct order (by MFI, descending), Original kept in place
  ord <- summ %>% arrange(desc(MFI_mean)) %>% pull(Construct)
  summ <- summ %>% mutate(Construct = factor(Construct, levels = ord))
  raw  <- raw  %>% filter(Construct %in% ord) %>%
    mutate(Construct = factor(Construct, levels = ord))

  is_ctrl  <- levels(summ$Construct) == ORIGINAL_NAME
  axis_col <- ifelse(is_ctrl, COL_ORIGINAL, "#2B2F33")
  axis_fce <- ifelse(is_ctrl, "bold", "plain")

  ctrl_mfi  <- summ$Ctrl_MFI[1]
  ctrl_pos  <- summ$Ctrl_Pos[1]
  ctrl_live <- summ$Ctrl_Live[1]

  n_rep <- max(summ$n_MFI, na.rm = TRUE)
  cap <- paste0(err_lab, ", n = ", n_rep, " biological replicates",
                if (SHOW_STATS) "  |  * p<0.05, ** p<0.01, *** p<0.001 (Welch t-test vs Original, BH-adjusted)" else "")

  # ---- helper: ranked column chart for one metric ---------------------------
  ranked_bar <- function(metric) {
    if (metric == "MFI") {
      d <- summ %>% mutate(m = MFI_mean, lo = err_lo(MFI_mean, MFI_sd, MFI_sem),
                           hi = err_hi(MFI_mean, MFI_sd, MFI_sem), rel = MFI_fold - 1)
      p_raw_pts <- raw %>% mutate(v = GFP_GeoMean)
      href <- ctrl_mfi; ylab <- "GFP GeoMean (MFI, a.u.)"
      ttl  <- "GFP expression level per 5'UTR variant"
    } else if (metric == "Pos") {
      d <- summ %>% mutate(m = Pos_mean, lo = err_lo(Pos_mean, Pos_sd, Pos_sem),
                           hi = err_hi(Pos_mean, Pos_sd, Pos_sem),
                           rel = (Pos_mean - Ctrl_Pos) / 100)
      p_raw_pts <- raw %>% mutate(v = GFP_Positive_Pct)
      href <- ctrl_pos; ylab <- "GFP-positive cells (%)"
      ttl  <- "GFP-positive population per 5'UTR variant"
    } else {
      d <- summ %>% mutate(m = Live_mean, lo = err_lo(Live_mean, Live_sd, Live_sem),
                           hi = err_hi(Live_mean, Live_sd, Live_sem),
                           rel = (Live_mean - Ctrl_Live) / 100)
      p_raw_pts <- raw %>% mutate(v = Live_Cell_Pct)
      href <- ctrl_live; ylab <- "Live cells (%)"
      ttl  <- "Cell viability per 5'UTR variant"
    }

    d <- d %>% mutate(
      fill_col = ifelse(Construct == ORIGINAL_NAME, "control",
                        ifelse(rel >= 0, "up", "down")),
      star   = ifelse(is.na(star), "", star),
      star_y = hi + 0.04 * diff(range(c(0, d$hi), na.rm = TRUE))
    )

    p <- ggplot(d, aes(x = Construct, y = m)) +
      geom_hline(yintercept = href, linetype = "dashed",
                 colour = COL_ORIGINAL, linewidth = 0.6) +
      geom_col(aes(fill = fill_col), width = 0.72) +
      geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.28,
                    linewidth = 0.45, colour = "#3A3F44") +
      geom_point(data = p_raw_pts, aes(x = Construct, y = v),
                 inherit.aes = FALSE, size = 1.5, alpha = 0.75,
                 colour = "#2B2F33", shape = 21, fill = "white", stroke = 0.5,
                 position = position_jitter(width = 0.13, height = 0)) +
      scale_fill_manual(values = c(control = COL_ORIGINAL, up = COL_UP, down = COL_DOWN),
                        labels = c(control = ORIGINAL_NAME, up = "at or above Original",
                                   down = "below Original"),
                        breaks = c("control", "up", "down"),
                        name = NULL) +
      labs(title = ttl, subtitle = title_suffix,
           x = NULL, y = ylab, caption = cap) +
      theme_pres() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,
                                       colour = axis_col, face = axis_fce, size = 11))

    if (metric == "MFI" && SHOW_STATS) {
      p <- p + geom_text(aes(y = star_y, label = star), size = 4.6,
                         colour = "#2B2F33", vjust = 0)
    }
    if (metric == "MFI" && LOG_MFI_AXIS) {
      p <- p + scale_y_log10()
    } else {
      p <- p + scale_y_continuous(expand = expansion(mult = c(0, 0.12)))
    }
    if (metric %in% c("Pos", "Live")) {
      p <- p + coord_cartesian(ylim = c(0, max(105, max(d$hi, na.rm = TRUE) * 1.05)))
    }
    p
  }

  save_fig(ranked_bar("MFI"),  paste0(tag, "_01_GFP_MFI_ranked"))
  save_fig(ranked_bar("Pos"),  paste0(tag, "_02_GFP_positive_ranked"))
  save_fig(ranked_bar("Live"), paste0(tag, "_03_Live_cell_ranked"))

  # ---- Fig 4: three readouts in one stacked panel ---------------------------
  long3 <- bind_rows(
    summ %>% transmute(Construct, Metric = "GFP GeoMean (MFI)",
                       m = MFI_mean,  lo = err_lo(MFI_mean, MFI_sd, MFI_sem),
                       hi = err_hi(MFI_mean, MFI_sd, MFI_sem), ref = Ctrl_MFI),
    summ %>% transmute(Construct, Metric = "GFP-positive (%)",
                       m = Pos_mean,  lo = err_lo(Pos_mean, Pos_sd, Pos_sem),
                       hi = err_hi(Pos_mean, Pos_sd, Pos_sem), ref = Ctrl_Pos),
    summ %>% transmute(Construct, Metric = "Live cells (%)",
                       m = Live_mean, lo = err_lo(Live_mean, Live_sd, Live_sem),
                       hi = err_hi(Live_mean, Live_sd, Live_sem), ref = Ctrl_Live)
  ) %>%
    mutate(Metric = factor(Metric, levels = c("GFP GeoMean (MFI)",
                                              "GFP-positive (%)",
                                              "Live cells (%)")),
           fill_col = ifelse(Construct == ORIGINAL_NAME, "control",
                             ifelse(m >= ref, "up", "down")))

  p4 <- ggplot(long3, aes(Construct, m)) +
    geom_hline(aes(yintercept = ref), linetype = "dashed",
               colour = COL_ORIGINAL, linewidth = 0.55) +
    geom_col(aes(fill = fill_col), width = 0.72) +
    geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.25,
                  linewidth = 0.4, colour = "#3A3F44") +
    scale_fill_manual(values = c(control = COL_ORIGINAL, up = COL_UP, down = COL_DOWN),
                      labels = c(control = ORIGINAL_NAME, up = "at or above Original",
                                 down = "below Original"),
                      breaks = c("control", "up", "down"), name = NULL) +
    facet_wrap(~Metric, ncol = 1, scales = "free_y") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.10))) +
    labs(title = "5'UTR variant screen: three FACS readouts",
         subtitle = paste0(title_suffix, "  |  constructs ordered by GFP MFI"),
         x = NULL, y = NULL, caption = cap) +
    theme_pres(base_size = 14) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,
                                     colour = axis_col, face = axis_fce, size = 10),
          panel.spacing.y = unit(1.0, "lines"))
  save_fig(p4, paste0(tag, "_04_three_readouts_panel"), h = 9)

  # ---- Fig 5: fold change vs Original (lollipop, horizontal) ----------------
  d5 <- summ %>%
    filter(Construct != ORIGINAL_NAME, !is.na(MFI_fold)) %>%
    mutate(Construct = factor(as.character(Construct),
                              levels = as.character(Construct)[order(MFI_fold)]),
           dir = ifelse(MFI_fold >= 1, "up", "down"),
           lab = paste0(sprintf("%.2f", MFI_fold), "x ", ifelse(is.na(star), "", star)))

  p5 <- ggplot(d5, aes(MFI_fold, Construct)) +
    geom_vline(xintercept = 1, linetype = "dashed",
               colour = COL_ORIGINAL, linewidth = 0.7) +
    geom_segment(aes(x = 1, xend = MFI_fold, y = Construct, yend = Construct,
                     colour = dir), linewidth = 1.1) +
    geom_point(aes(colour = dir), size = 3.4) +
    geom_text(aes(label = lab), hjust = ifelse(d5$MFI_fold >= 1, -0.18, 1.18),
              size = 3.6, colour = "#2B2F33") +
    scale_colour_manual(values = c(up = COL_UP, down = COL_DOWN), guide = "none") +
    scale_x_continuous(expand = expansion(mult = c(0.14, 0.14))) +
    labs(title = "GFP MFI relative to Original",
         subtitle = title_suffix,
         x = "Fold change vs Original", y = NULL, caption = cap) +
    theme_pres(base_size = 14) +
    theme(panel.grid.major.y = element_blank(),
          panel.grid.major.x = element_line(colour = "#E4E8EB", linewidth = 0.4),
          axis.text.y = element_text(size = 11))
  save_fig(p5, paste0(tag, "_05_MFI_fold_vs_Original"), h = 9)

  # ---- Fig 6: intensity vs fraction, sized by viability ---------------------
  top_hits <- summ %>% arrange(desc(MFI_mean)) %>%
    slice_head(n = LABEL_TOP_N) %>% pull(Construct) %>% as.character()
  d6 <- summ %>% mutate(grp = ifelse(Construct == ORIGINAL_NAME, ORIGINAL_NAME, "Variant"))

  p6 <- ggplot(d6, aes(Pos_mean, MFI_mean)) +
    geom_hline(yintercept = ctrl_mfi, linetype = "dashed",
               colour = COL_ORIGINAL, linewidth = 0.5) +
    geom_vline(xintercept = ctrl_pos, linetype = "dashed",
               colour = COL_ORIGINAL, linewidth = 0.5) +
    geom_point(aes(size = Live_mean, fill = grp),
               shape = 21, colour = "#2B2F33", stroke = 0.5, alpha = 0.9) +
    scale_fill_manual(values = setNames(c(COL_ORIGINAL, COL_UP),
                                        c(ORIGINAL_NAME, "Variant")), name = NULL) +
    geom_point(data = d6 %>% filter(Construct == ORIGINAL_NAME),
               aes(size = Live_mean), shape = 21, fill = COL_ORIGINAL,
               colour = "#2B2F33", stroke = 1.1, show.legend = FALSE) +
    scale_size_continuous(range = c(3, 10), name = "Live cells (%)") +
    guides(fill = guide_legend(override.aes = list(size = 5))) +
    labs(title = "Expression strength vs transduced fraction",
         subtitle = paste0(title_suffix,
                           "  |  dashed lines = Original; bubble size = viability"),
         x = "GFP-positive cells (%)", y = "GFP GeoMean (MFI, a.u.)",
         caption = "Top-right quadrant = brighter and more uniform than Original") +
    theme_pres() +
    theme(panel.grid.major.x = element_line(colour = "#E4E8EB", linewidth = 0.4))

  lab_d <- d6 %>% filter(as.character(Construct) %in% c(top_hits, ORIGINAL_NAME))
  if (HAS_REPEL) {
    p6 <- p6 + geom_text_repel(data = lab_d, aes(label = Construct),
                               size = 4, min.segment.length = 0,
                               box.padding = 0.45, max.overlaps = 40,
                               seed = 1, show.legend = FALSE)
  } else {
    p6 <- p6 + geom_text(data = lab_d, aes(label = Construct),
                         size = 4, vjust = -1.1, show.legend = FALSE)
  }
  if (LOG_MFI_AXIS) p6 <- p6 + scale_y_log10()
  save_fig(p6, paste0(tag, "_06_MFI_vs_GFPpositive"))

  # ---- Fig 7: z-score heatmap across the three readouts ---------------------
  z <- function(x) if (sd(x, na.rm = TRUE) > 0) (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE) else x * 0
  d7 <- summ %>%
    transmute(Construct,
              `GFP MFI`        = z(MFI_mean),
              `GFP-positive %` = z(Pos_mean),
              `Live cell %`    = z(Live_mean)) %>%
    pivot_longer(-Construct, names_to = "Metric", values_to = "Z") %>%
    mutate(Metric = factor(Metric, levels = c("GFP MFI", "GFP-positive %", "Live cell %")))

  p7 <- ggplot(d7, aes(Construct, Metric, fill = Z)) +
    geom_tile(colour = "white", linewidth = 0.7) +
    scale_fill_gradient2(low = COL_DOWN, mid = COL_MID, high = COL_UP,
                         midpoint = 0, name = "z-score") +
    labs(title = "Variant profile across all three readouts",
         subtitle = paste0(title_suffix, "  |  z-score within each readout"),
         x = NULL, y = NULL,
         caption = "Constructs ordered by GFP MFI (highest on the left)") +
    theme_pres(base_size = 14) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,
                                     colour = axis_col, face = axis_fce, size = 10),
          panel.grid = element_blank(),
          axis.line.x = element_blank(),
          legend.position = "right", legend.key.height = unit(1.6, "lines"))
  save_fig(p7, paste0(tag, "_07_zscore_heatmap"), h = 5.2)

  message("  -> figures written for: ", tag)
  invisible(NULL)
}


# ------------------------------ choose focus set -----------------------------

DAY_ORDER_DEFAULT <- c("D1", "D3", "D5", "D7", "D9", "D11")
day_rank <- function(d) {
  i <- match(d, DAY_ORDER_DEFAULT)
  num <- suppressWarnings(as.numeric(str_remove(d, "^D")))
  ifelse(!is.na(i), i, ifelse(!is.na(num), num, 0))
}

combos <- dat %>%
  group_by(Day, Condition) %>%
  summarise(n_values = sum(!is.na(GFP_GeoMean)),
            n_constructs = n_distinct(Construct), .groups = "drop") %>%
  mutate(day_rank = day_rank(Day)) %>%
  arrange(desc(n_constructs), desc(day_rank), desc(n_values))

if (is.null(FOCUS_DAY))       FOCUS_DAY       <- combos$Day[1]
if (is.null(FOCUS_CONDITION)) FOCUS_CONDITION <- combos$Condition[1]

message("Main figures use Day = ", FOCUS_DAY, ", Condition = ", FOCUS_CONDITION)

run_combo <- function(day, cond, tag) {
  s <- summ_all %>% filter(Day == day, Condition == cond)
  r <- dat      %>% filter(Day == day, Condition == cond)
  if (nrow(s) < 2 || all(is.na(s$MFI_mean))) {
    message("  (skipped ", tag, " - not enough data)")
    return(invisible(NULL))
  }
  suffix <- paste0(day, if (cond != "All") paste0("  |  ", cond) else "")
  build_figures(s, r, tag, suffix)
}

run_combo(FOCUS_DAY, FOCUS_CONDITION, "MAIN")

if (MAKE_ALL_COMBOS && nrow(combos) > 1) {
  for (i in seq_len(nrow(combos))) {
    d <- combos$Day[i]; cc <- combos$Condition[i]
    if (d == FOCUS_DAY && cc == FOCUS_CONDITION) next
    run_combo(d, cc, paste0(d, "_", str_replace_all(cc, "[^A-Za-z0-9]+", "-")))
  }
}


# ------------------------------ trajectory (if >1 day) -----------------------

if (length(unique(dat$Day)) > 1) {
  day_lv <- c("D1", "D3", "D5", "D7", "D9", "D11")
  day_lv <- c(day_lv[day_lv %in% dat$Day], setdiff(unique(dat$Day), day_lv))

  top_n <- summ_all %>%
    filter(Day == FOCUS_DAY, Condition == FOCUS_CONDITION,
           Construct != ORIGINAL_NAME) %>%
    arrange(desc(MFI_mean)) %>% slice_head(n = 6) %>% pull(Construct)
  keep <- c(ORIGINAL_NAME, as.character(top_n))

  traj <- summ_all %>%
    filter(Construct %in% keep) %>%
    mutate(Day = factor(Day, levels = day_lv),
           Construct = factor(Construct, levels = keep))

  pt <- ggplot(traj, aes(Day, MFI_mean, colour = Construct, group = Construct)) +
    geom_errorbar(aes(ymin = MFI_mean - MFI_sd, ymax = MFI_mean + MFI_sd),
                  width = 0.12, linewidth = 0.4, alpha = 0.8) +
    geom_line(linewidth = 1.0) +
    geom_point(size = 2.8) +
    facet_wrap(~Condition) +
    scale_colour_manual(values = c(COL_ORIGINAL,
                                   c("#1B6CA8", "#3C9D9B", "#E8A33D", "#7B5EA7",
                                     "#4C956C", "#9B5DE5")[seq_len(length(keep) - 1)]),
                        name = NULL) +
    labs(title = "GFP MFI over time: Original vs top variants",
         subtitle = paste0("Top 6 variants selected at ", FOCUS_DAY,
                           " | ", FOCUS_CONDITION),
         x = NULL, y = "GFP GeoMean (MFI, a.u.)",
         caption = "mean +/- SD") +
    theme_pres()
  if (LOG_MFI_AXIS) pt <- pt + scale_y_log10()
  save_fig(pt, "MAIN_08_MFI_trajectory")
}

message("\nDone. Output directory: ", normalizePath(OUTPUT_DIR))
message("Each figure is saved as .png (300 dpi, for slides) and .pdf (vector).")
