# =============================================================================
# Helper: build an EXAMPLE plate map + simulated FACS data
# -----------------------------------------------------------------------------
# Purpose
#   1) Give you a ready-to-edit Plate_Map.csv for 31 variants + Original x 3 reps
#   2) Generate fake numbers so you can see what the figures look like
#      before the real FlowJo export is ready.
#
# Run:  Rscript make_demo_input.R
#       cd demo && Rscript ../plot_facs_presentation.R
#
# Layout assumed (EDIT if your pipetting differs):
#   Replicate 1 = columns 1-4, Replicate 2 = columns 5-8, Replicate 3 = columns 9-12
#   Within each 8x4 block, constructs run row-major: A1..A4, B1..B4, ... H1..H4
#   Position 1 = Original, positions 2-32 = UTR01 .. UTR31
# =============================================================================

set.seed(42)

OUT_DIR   <- "demo"
DAYS      <- c("D1", "D3", "D5", "D7", "D9", "D11")
CONDITION <- "GS"

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

rows <- LETTERS[1:8]
cols <- 1:12

# ---------------------------- plate map --------------------------------------

plate <- expand.grid(col = cols, row = rows, stringsAsFactors = FALSE)
plate$Well <- paste0(plate$row, plate$col)
plate$Replicate <- ifelse(plate$col <= 4, 1L, ifelse(plate$col <= 8, 2L, 3L))
block_col <- ((plate$col - 1) %% 4) + 1
row_idx   <- match(plate$row, rows)
plate$Position <- (row_idx - 1) * 4 + block_col          # 1..32 within replicate

construct_names <- c("Original", sprintf("UTR%02d", 1:31))
plate$Construct <- construct_names[plate$Position]

plate_map <- data.frame(
  Well        = plate$Well,
  Sample_File = paste0(plate$Well, ".fcs"),
  Construct   = plate$Construct,
  Replicate   = plate$Replicate,
  DNA_Prep    = "",
  DNA_Batch   = "",
  Notes       = "",
  stringsAsFactors = FALSE
)
plate_map <- plate_map[order(match(substr(plate_map$Well, 1, 1), rows),
                            as.integer(substr(plate_map$Well, 2, 3))), ]

write.csv(plate_map, file.path(OUT_DIR, "Plate_Map.csv"),
          row.names = FALSE, fileEncoding = "UTF-8", na = "")
write.csv(plate_map, "Plate_Map_EXAMPLE_filled.csv",
          row.names = FALSE, fileEncoding = "UTF-8", na = "")

# ---------------------------- simulated FACS data ----------------------------
# Each variant gets a "true" strength; MFI grows with day, viability drifts.

true_strength <- setNames(
  c(1.00, exp(rnorm(31, mean = 0.05, sd = 0.45))),
  construct_names
)
true_pos_base <- setNames(
  pmin(95, pmax(5, 45 + 28 * log(true_strength) + rnorm(32, 0, 4))),
  construct_names
)

make_day <- function(day) {
  d_idx <- match(day, DAYS)
  growth <- c(0.55, 0.75, 0.90, 1.00, 1.06, 1.10)[d_idx]
  sel    <- c(0.45, 0.60, 0.78, 0.90, 0.96, 1.00)[d_idx]

  mfi  <- 2600 * true_strength[plate_map$Construct] * growth *
          exp(rnorm(nrow(plate_map), 0, 0.09))
  pos  <- pmin(99, pmax(1, true_pos_base[plate_map$Construct] * sel +
                          rnorm(nrow(plate_map), 0, 3)))
  live <- pmin(98, pmax(55, 92 - 6 * (1 - sel) * 10 / 10 -
                          2.0 * pmax(0, log(true_strength[plate_map$Construct])) +
                          rnorm(nrow(plate_map), 0, 2.2)))

  data.frame(
    Day              = day,
    Condition        = CONDITION,
    Acquisition_Date = format(as.Date("2026-08-03") + (d_idx - 1) * 2, "%Y-%m-%d"),
    Well             = plate_map$Well,
    Sample_File      = plate_map$Sample_File,
    Live_Cell_Pct    = round(live, 1),
    GFP_Positive_Pct = round(pos, 1),
    GFP_GeoMean      = round(mfi, 0),
    Notes            = "",
    stringsAsFactors = FALSE
  )
}

facs <- do.call(rbind, lapply(DAYS, make_day))
write.csv(facs, file.path(OUT_DIR, "FACS_Data.csv"),
          row.names = FALSE, fileEncoding = "UTF-8", na = "")

cat("Wrote:\n",
    "  ", file.path(OUT_DIR, "Plate_Map.csv"), "\n",
    "  ", file.path(OUT_DIR, "FACS_Data.csv"), " (simulated)\n",
    "  Plate_Map_EXAMPLE_filled.csv  <- copy over your real Plate_Map.csv if the layout matches\n\n",
    "Preview the figures with:\n",
    "  cd demo && Rscript ../plot_facs_presentation.R\n", sep = "")
