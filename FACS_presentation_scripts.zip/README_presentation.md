# 발표용 FACS 그래프 스크립트

기존 `plot_facs_longitudinal.R`은 그대로 두고, **발표용 figure 전용** 스크립트를 새로 추가한 것입니다.
입력 파일 포맷(`Plate_Map.csv` + `FACS_Data.csv`)은 기존과 동일하므로 템플릿을 다시 만들 필요 없습니다.

## 실행

```bash
# 1) (선택) 예시 plate map + 가상 데이터로 그림 먼저 확인
Rscript make_demo_input.R
cd demo && Rscript ../plot_facs_presentation.R

# 2) 실제 데이터
#    Plate_Map.csv 의 Construct / Replicate 를 채운 뒤
Rscript plot_facs_presentation.R
```

결과는 `FACS_presentation/` 에 **PNG(300 dpi, 슬라이드 붙여넣기용)** 와 **PDF(벡터, 크기 조절용)** 로 같이 저장됩니다.
figure 크기는 13.33 × 7.5 inch = 16:9 슬라이드 전체 크기 기준입니다.

## 만들어지는 그림

| 파일 | 내용 |
|---|---|
| `MAIN_01_GFP_MFI_ranked` | GFP GeoMean 랭킹 bar + replicate 점 + SD + 유의성 별표 |
| `MAIN_02_GFP_positive_ranked` | GFP-positive (%) 랭킹 |
| `MAIN_03_Live_cell_ranked` | Live cell (%) 랭킹 |
| `MAIN_04_three_readouts_panel` | **3가지 지표 한 장에** (MFI 순서로 정렬 고정) — 메인 슬라이드용 |
| `MAIN_05_MFI_fold_vs_Original` | Original 대비 fold change lollipop, 배수 + 별표 라벨 |
| `MAIN_06_MFI_vs_GFPpositive` | 발현 세기 vs 발현 비율 산점도, 버블 크기 = 생존율 |
| `MAIN_07_zscore_heatmap` | 3지표 z-score 히트맵 (한눈에 프로파일 비교) |
| `MAIN_08_MFI_trajectory` | 시점이 여러 개일 때 Original vs 상위 6개 궤적 |

CSV도 같이 나옵니다: `summary_by_construct.csv` (평균/SD/SEM/fold/p-value), `data_wells_long.csv` (정리된 raw).

## 디자인 규칙

- Original은 항상 **빨간 막대 + 빨간 점선 기준선 + 빨간 축 라벨**로 고정 → 슬라이드에서 대조군이 바로 보입니다.
- Original보다 높으면 파랑, 낮으면 회색. 색으로 메시지가 먼저 전달됩니다.
- bar는 mean, error bar는 SD, 흰 점 3개가 실제 replicate 값입니다 (n=3이므로 개별 점을 보여주는 게 정직합니다).
- 모든 텍스트를 ASCII로 제한했습니다. 오프라인 리눅스 서버가 C locale이면 `±`, `≥` 같은 문자가 PDF에서 깨지면서 warning이 쏟아지는데, 그걸 피하려고 `mean +/- SD` 식으로 썼습니다.

## 스크립트 상단에서 바꿀 만한 것

```r
FOCUS_DAY       <- NULL     # NULL이면 가장 늦은 시점 자동 선택. "D11" 처럼 지정 가능
FOCUS_CONDITION <- NULL     # "GS" 등
ERRORBAR        <- "SD"     # "SEM" 으로 바꾸면 error bar가 SEM
LOG_MFI_AXIS    <- FALSE    # MFI가 10배 이상 벌어지면 TRUE 권장
SHOW_STATS      <- TRUE     # Original 대비 Welch t-test, BH 보정
LABEL_TOP_N     <- 8        # 산점도에 이름 붙일 상위 개수
```

## 통계에 대한 주의

n=3에서의 t-test는 검정력이 매우 낮습니다. 별표는 "이 정도면 재현될 것 같다"는 **우선순위 힌트**로 쓰시고,
발표에서 결론으로 밀 후보는 fold change 크기 + 3 replicate의 산포 + GFP-positive %까지 같이 보고 고르시는 게 안전합니다.
BH 보정을 넣긴 했지만 31개 비교라 보정 후 유의한 것만 남기면 진짜 후보를 놓칠 수 있어서, 그림에는 raw 값도 다 보이게 해뒀습니다.

## Plate_Map 레이아웃

`Plate_Map_EXAMPLE_filled.csv` 는 아래 가정으로 채운 예시입니다. **실제 피펫팅과 다르면 반드시 수정**하세요.

- Replicate 1 = column 1–4, Replicate 2 = column 5–8, Replicate 3 = column 9–12
- 각 블록 안에서 A1→A4→B1→… 순서, 1번 자리가 Original, 2–32번이 UTR01–UTR31

레이아웃만 맞으면 그대로 `Plate_Map.csv` 로 덮어쓰시면 됩니다.
